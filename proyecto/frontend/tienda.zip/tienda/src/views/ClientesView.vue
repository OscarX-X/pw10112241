<template>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4>Clientes
                    <RouterLink to="/clientes/create" class="btn btn-primary float-end">
                        Agregar
                    </RouterLink>
                </h4>
            </div>
            <div class="card-body">
                
            </div>
        </div>
    </div>
</template>